package com.btos.views;

public interface MainMenuView {
	public void displayUserMenu(User userType);
}
